using UnityEngine;

/// <summary>
/// CameraFollow — Camera góc CỐ ĐỊNH (khóa cứng), theo player mượt
/// </summary>
public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public Vector3   offset      = new Vector3(0f, 14f, -9f);
    public float     followSpeed = 5f;

    private Quaternion lockedRotation;

    void Start() { lockedRotation = transform.rotation; }

    void LateUpdate()
    {
        if (target == null) return;
        Vector3 desired = target.position + offset;
        transform.position = Vector3.Lerp(transform.position, desired, followSpeed * Time.deltaTime);
        transform.rotation = lockedRotation; // KHÓA CỨNG
    }
}
